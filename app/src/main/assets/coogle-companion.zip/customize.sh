#!/system/bin/sh
. "$MODPATH/copy-google.sh"
set_perm_recursive "$MODPATH/system" 0 0 0755 0644
for script in boot-completed.sh setup.sh uninstall.sh status.sh features.sh post-fs-data.sh native-translate.sh copy-google.sh mount-google.sh; do
    set_perm "$MODPATH/$script" 0 0 0755
done
. "$MODPATH/features.sh"
load_features /dev/null
if grep -q '^controlVersion=1$' /data/adb/modules/coogle_companion/module.prop 2>/dev/null; then
    load_features /data/adb/modules/coogle_companion/features.conf
fi
save_features "$MODPATH/features.conf" || abort "Cannot save component choices"
MODDIR=$MODPATH
apply_features || abort "Cannot prepare selected components"
. "$MODPATH/native-translate.sh"
prepare_native_translation || abort "Cannot prepare native translation configuration"
ui_print "Google system app and software hotword support combined. Reboot required."
ui_print "Hey Google follows the Coogle switch; live translation enables automatically after reboot."
